<?php

return array(
	'name'			=> 'Group name',
);
