<?php

return array(
	'name'          => 'Role name',
	'filter'        => 'Special permissions',

	'permissions'   => array(
		''          => 'None',
		'A'         => 'Allow all access',
		'D'         => 'Deny all access',
		'R'         => 'Revoke assigned permissions',
	),
);
