<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2013-09-29 13:30:45 --> Fatal Error - Call to undefined method Oil\Console::help() in /data/www/fuelphp/1.7/develop/fuel/packages/oil/classes/command.php on line 94
