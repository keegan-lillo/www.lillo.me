<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2013-07-23 20:36:23 --> Error - Call to undefined function Oil\get_include_paths() in /data/www/fuelphp/1.7/develop/fuel/packages/oil/classes/command.php on line 151
ERROR - 2013-07-23 20:49:34 --> Error - Call to undefined method Phar::PharFileInfo() in /data/www/fuelphp/1.7/develop/fuel/packages/oil/classes/command.php on line 158
